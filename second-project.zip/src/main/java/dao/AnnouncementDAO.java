package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dto.AnnouncementDTO;
import jdbc.DBConnection;

public class AnnouncementDAO {
    private Connection conn;
    private PreparedStatement pstmt;
    private ResultSet rs;

    public AnnouncementDAO() {
        conn = DBConnection.getConnection();
    }

    // 공지 추가
    public int insertAnnouncement(AnnouncementDTO dto) {
        int result = 0;
        try {
            String sql = "INSERT INTO announcements (num, category, title, detail, emp_name) VALUES (?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, dto.getNum());
            pstmt.setString(2, dto.getCategory());
            pstmt.setString(3, dto.getTitle());
            pstmt.setString(4, dto.getDetail());
            pstmt.setString(5, dto.getEmp_name());
            
            result = pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return result;
    }

    // 공지 조회 (전체)
    public List<AnnouncementDTO> getAllAnnouncements() {
        List<AnnouncementDTO> list = new ArrayList<>();
        try {
        	String sql = "SELECT a.num, a.category, a.title, a.detail, e.emp_name " +
                    "FROM announcements a " +
                    "JOIN employees e ON a.emp_name = e.emp_name";
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                int num = rs.getInt("num");
                String category = rs.getString("category");
                String title = rs.getString("title");
                String detail = rs.getString("detail");
                String emp_name = rs.getString("emp_name");
                
                list.add(new AnnouncementDTO(num, category, title, detail, emp_name));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return list;
    }

    //공지 개수 반환하기
    public int getTotalAnnouncementsCount() {
        int count = 0;
        try {
            String sql = "SELECT COUNT(*) FROM announcements";
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return count;
    }

    //공지사항 가져오기(페이지별)
    public List<AnnouncementDTO> getAnnouncements(int ofset, int pageSize) {
        List<AnnouncementDTO> list = new ArrayList<>();
        try {
            String sql = "SELECT num, category, title, detail, emp_name FROM announcements ORDER BY num ASC LIMIT ?, ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, ofset);
            pstmt.setInt(2, pageSize);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                int num = rs.getInt("num");
                String category = rs.getString("category");
                String title = rs.getString("title");
                String detail = rs.getString("detail");
                String emp_name = rs.getString("emp_name");
                
                list.add(new AnnouncementDTO(num, category, title, detail, emp_name));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return list;
    }
    
    //공지 조회
    public AnnouncementDTO getDetailAnnouncements(int num) {
        AnnouncementDTO announcement = null;
        try {
            String sql = "SELECT num, category, title, detail, emp_name FROM announcements WHERE num = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, num); //
            rs = pstmt.executeQuery();
            
            if (rs.next()) { 
                int Num = rs.getInt("num");
                String category = rs.getString("category");
                String title = rs.getString("title");
                String detail = rs.getString("detail");
                String emp_name = rs.getString("emp_name");
                announcement = new AnnouncementDTO(Num, category, title, detail, emp_name);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return announcement; 
    }
    
    public boolean deleteAnnouncement(int num) {
        String sql = "DELETE FROM announcements WHERE id = ?";
        boolean isDeleted = false;

        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, num);
            int result = pstmt.executeUpdate();

            if (result > 0) {
                isDeleted = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return isDeleted;
    }
    
    public boolean updateAnnouncement(int num, String title, String category, String emp_name, String detail) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DBConnection.getConnection();
            String sql = "UPDATE announcements SET title = ?, category = ?, emp_name = ?, detail = ? WHERE num = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, title);
            pstmt.setString(2, category);
            pstmt.setString(3, emp_name);
            pstmt.setString(4, detail);
            pstmt.setInt(5, num);

            int rowsUpdated = pstmt.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false; 
        } finally {
            
        }
    }

    // DB 해제
    public void close() {
        try {
            if (pstmt != null) pstmt.close();
            if (rs != null) rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
