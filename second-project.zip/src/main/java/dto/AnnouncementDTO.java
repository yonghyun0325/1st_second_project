package dto;

public class AnnouncementDTO {
	
	private int num;
	private int ofset;
	private int pagesize;
    private String category;
    private String title;
	private String detail;
	private String emp_name;
	
	public AnnouncementDTO(int num) {
		this.num = 0;
	}
	
	public AnnouncementDTO() {
		this.num = 0;
        this.category = "";
        this.title = "";
        this.detail = "";
        this.emp_name = "";
	}
	
	public AnnouncementDTO(int num, String category, String title, String detail, String emp_name) {
		this.num = num;
        this.category = category;
        this.title = title;
        this.detail = detail;
        this.emp_name = emp_name;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getOffset() {
		return ofset;
	}
	public void setOffset(int ofset) {
		this.ofset = ofset;
	}
	public int getPagesize() {
		return pagesize;
	}
	public void setPagesize(int pagesize) {
		this.pagesize = pagesize;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	

    
}
